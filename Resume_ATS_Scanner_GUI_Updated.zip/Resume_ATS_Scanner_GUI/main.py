import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from resume_parser import ResumeParser
from job_matcher import JobMatcher
from section_analyzer import SectionAnalyzer
from formatting_checker import FormattingChecker
from report_generator import ReportGenerator

class ResumeATSApp:
    def __init__(self, root):
        self.root = root
        root.title("Resume ATS Scanner")
        root.geometry("850x650")

        self.resume_path = tk.StringVar()
        self.job_path = tk.StringVar()

        tk.Label(root, text="RESUME ATS SCANNER", font=("Arial", 20, "bold")).pack(pady=15)
        tk.Label(root, text="Select files using the Browse buttons and analyze your resume").pack()

        frame = tk.Frame(root)
        frame.pack(fill="x", padx=40, pady=20)

        tk.Label(frame, text="Resume File (PDF / DOCX)", font=("Arial", 11, "bold")).grid(row=0, column=0, sticky="w")
        tk.Entry(frame, textvariable=self.resume_path, width=70).grid(row=1, column=0, pady=5)
        tk.Button(frame, text="Browse Resume", command=self.browse_resume).grid(row=1, column=1, padx=10)

        tk.Label(frame, text="Job Description (TXT)", font=("Arial", 11, "bold")).grid(row=2, column=0, sticky="w", pady=(15,0))
        tk.Entry(frame, textvariable=self.job_path, width=70).grid(row=3, column=0, pady=5)
        tk.Button(frame, text="Browse Job File", command=self.browse_job).grid(row=3, column=1, padx=10)

        tk.Button(root, text="ANALYZE RESUME", font=("Arial", 12, "bold"), command=self.analyze).pack(pady=10)

        self.output = scrolledtext.ScrolledText(root, width=95, height=25, font=("Consolas", 10))
        self.output.pack(padx=20, pady=10)

    def browse_resume(self):
        path = filedialog.askopenfilename(
            title="Select Resume",
            filetypes=[("Resume Files", "*.pdf *.docx"), ("PDF Files", "*.pdf"), ("Word Files", "*.docx")]
        )
        if path:
            self.resume_path.set(path)

    def browse_job(self):
        path = filedialog.askopenfilename(
            title="Select Job Description",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if path:
            self.job_path.set(path)

    def analyze(self):
        if not self.resume_path.get():
            messagebox.showwarning("Missing File", "Please click Browse Resume and select your resume.")
            return
        if not self.job_path.get():
            messagebox.showwarning("Missing File", "Please click Browse Job File and select a job description.")
            return

        try:
            resume = ResumeParser.parse_resume(self.resume_path.get())
            with open(self.job_path.get(), "r", encoding="utf-8") as f:
                job = f.read()

            keyword = JobMatcher.match_keywords(resume, job)
            sections = SectionAnalyzer.analyze_sections(resume)
            formatting = FormattingChecker.check_formatting(resume)

            self.output.delete("1.0", tk.END)
            self.output.insert(tk.END, "RESUME ATS SCANNER REPORT\n")
            self.output.insert(tk.END, "=" * 60 + "\n\n")
            self.output.insert(tk.END, f"ATS Match Percentage: {keyword['match_percentage']}%\n\n")

            self.output.insert(tk.END, "MATCHED KEYWORDS:\n")
            self.output.insert(tk.END, ", ".join(keyword["matched_keywords"]) or "None")
            self.output.insert(tk.END, "\n\nMISSING KEYWORDS:\n")
            self.output.insert(tk.END, ", ".join(keyword["missing_keywords"]) or "None")

            self.output.insert(tk.END, "\n\nSECTION ANALYSIS:\n")
            for k, v in sections.items():
                self.output.insert(tk.END, f"{k}: {'FOUND' if v else 'MISSING'}\n")

            self.output.insert(tk.END, "\nFORMATTING ANALYSIS:\n")
            for k, v in formatting.items():
                self.output.insert(tk.END, f"{k}: {v}\n")

            report = ReportGenerator.generate_report(keyword, sections, formatting)
            report_file = ReportGenerator.save_report(report)
            self.output.insert(tk.END, f"\nReport saved: {report_file}\n")

            messagebox.showinfo("Success", "Resume analysis completed successfully!")

        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    ResumeATSApp(root)
    root.mainloop()
