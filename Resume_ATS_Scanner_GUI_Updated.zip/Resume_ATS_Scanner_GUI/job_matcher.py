import re
from collections import Counter

class JobMatcher:
    STOP_WORDS = {"and","or","the","a","an","to","of","in","for","with","on","is","are","be","as","at","by","this","that","will","from","should","have","has","experience","work","job"}

    @staticmethod
    def preprocess_text(text):
        text = re.sub(r"[^a-zA-Z0-9+#.\s]", " ", text.lower())
        return [w for w in text.split() if w not in JobMatcher.STOP_WORDS and len(w) > 2]

    @staticmethod
    def match_keywords(resume_text, job_description):
        resume_words = set(JobMatcher.preprocess_text(resume_text))
        words = JobMatcher.preprocess_text(job_description)
        keywords = [w for w, _ in Counter(words).most_common(30)]
        matched = [w for w in keywords if w in resume_words]
        missing = [w for w in keywords if w not in resume_words]
        score = round((len(matched) / len(keywords) * 100), 2) if keywords else 0
        return {"matched_keywords": matched, "missing_keywords": missing, "match_percentage": score}
