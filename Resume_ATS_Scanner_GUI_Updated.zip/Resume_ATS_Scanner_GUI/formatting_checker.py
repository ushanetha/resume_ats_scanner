import re

class FormattingChecker:
    @staticmethod
    def check_formatting(text):
        lines = [x.strip() for x in text.split("\n") if x.strip()]
        result = {
            "Total Lines": len(lines),
            "Email Present": bool(re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)),
            "Phone Present": bool(re.search(r"(\+91[-\s]?)?[6-9]\d{9}", text)),
            "Bullet Points Found": sum(1 for x in lines if x.startswith(("-", "*", "•"))),
            "Long Lines": sum(1 for x in lines if len(x) > 150)
        }
        result["Formatting Score"] = (
            (25 if result["Email Present"] else 0) +
            (25 if result["Phone Present"] else 0) +
            (25 if result["Bullet Points Found"] else 0) +
            (25 if result["Long Lines"] == 0 else 0)
        )
        return result
