class SectionAnalyzer:
    REQUIRED_SECTIONS = {
        "Contact Information": ["email", "phone", "contact"],
        "Education": ["education", "qualification"],
        "Skills": ["skills", "technical skills"],
        "Experience": ["experience", "work experience", "employment"],
        "Projects": ["projects", "project experience"]
    }

    @staticmethod
    def analyze_sections(text):
        text = text.lower()
        return {section: any(k in text for k in keywords)
                for section, keywords in SectionAnalyzer.REQUIRED_SECTIONS.items()}
