import os
import PyPDF2
from docx import Document

class ResumeParser:
    @staticmethod
    def parse_resume(file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError("Resume file not found.")
        extension = os.path.splitext(file_path)[1].lower()
        if extension == ".pdf":
            with open(file_path, "rb") as file:
                reader = PyPDF2.PdfReader(file)
                return "\n".join(page.extract_text() or "" for page in reader.pages)
        elif extension == ".docx":
            document = Document(file_path)
            return "\n".join(p.text for p in document.paragraphs if p.text.strip())
        raise ValueError("Please select a PDF or DOCX resume.")
