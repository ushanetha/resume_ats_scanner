# Resume ATS Scanner - GUI Version

## New GUI Feature
This version removes the need to type file paths manually.

### Steps
1. Run `python main.py`
2. Click **Browse Resume**
3. Select your PDF or DOCX resume
4. Click **Browse Job File**
5. Select `job_description.txt`
6. Click **ANALYZE RESUME**

A results window will display the ATS analysis.
