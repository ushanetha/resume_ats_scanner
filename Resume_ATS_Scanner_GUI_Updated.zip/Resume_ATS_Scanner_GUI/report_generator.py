import os
import pandas as pd
from datetime import datetime

class ReportGenerator:
    @staticmethod
    def generate_report(keyword_result, section_result, formatting_result):
        data = [
            {"Category": "ATS Match Percentage", "Result": f"{keyword_result['match_percentage']}%"},
            {"Category": "Matched Keywords", "Result": ", ".join(keyword_result["matched_keywords"])},
            {"Category": "Missing Keywords", "Result": ", ".join(keyword_result["missing_keywords"])}
        ]
        data += [{"Category": f"{k} Section", "Result": "Found" if v else "Missing"} for k, v in section_result.items()]
        data += [{"Category": k, "Result": v} for k, v in formatting_result.items()]
        return pd.DataFrame(data)

    @staticmethod
    def save_report(dataframe):
        os.makedirs("reports", exist_ok=True)
        name = "reports/ats_report_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".csv"
        dataframe.to_csv(name, index=False)
        return name
